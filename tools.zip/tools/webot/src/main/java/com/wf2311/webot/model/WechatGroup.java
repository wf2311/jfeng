package com.wf2311.webot.model;

public class WechatGroup {

}
