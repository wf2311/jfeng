package com.wf2311.webot.service;

import com.alibaba.fastjson.JSONObject;
import com.wf2311.webot.exception.WechatException;
import com.wf2311.webot.model.WechatContact;
import com.wf2311.webot.model.WechatMeta;

import java.io.File;

/**
 * @author wf2311
 * @time 2017/5/20 00:49.
 */
public interface WechatService {
    /**
     * 获取UUID
     * @return
     */
    String getUUID() throws WechatException;

    /**
     * 获取登录二维码
     *
     * @param uuid
     * @param file
     * @return
     * @throws WechatException
     */
    void copyQrCode(String uuid,File file) throws WechatException;

    /**
     * 微信初始化
     * @param wechatMeta
     * @throws WechatException
     */
    void wxInit(WechatMeta wechatMeta) throws WechatException;

    /**
     * 开启状态通知
     * @return
     */
    void openStatusNotify(WechatMeta wechatMeta) throws WechatException;

    /**
     * 获取联系人
     * @param wechatMeta
     * @return
     */
    WechatContact getContact(WechatMeta wechatMeta) throws WechatException;

    /**
     * 选择同步线路
     *
     * @param wechatMeta
     * @return
     * @throws WechatException
     */
    void choiceSyncLine(WechatMeta wechatMeta) throws WechatException;

    /**
     * 消息检查
     * @param wechatMeta
     * @return
     */
    int[] syncCheck(WechatMeta wechatMeta) throws WechatException;

    /**
     * 处理聊天信息
     * @param data
     */
    void handleMsg(WechatMeta wechatMeta, JSONObject data) throws WechatException;

    /**
     * 获取最新消息
     * @param meta
     * @return
     */
    JSONObject webwxsync(WechatMeta meta) throws WechatException;
}
