package com.wf2311.webot.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * @author wf2311
 * @time 2017/5/20 17:44.
 */
public class FileUtils {
    public static File toFile(byte[] bytes, String filename) throws IOException {
        return Files.write(Paths.get(filename), bytes).toFile();
    }
}
