package com.wf2311.webot.robot;


import com.wf2311.webot.message.Message;

/**
 * @author wf2311
 * @time 2017/5/20 00:36.
 */
public interface Robot {
    Message talk(Message message);
}
