package com.wf2311.webot.message;

/**
 * @author wf2311
 * @time 2017/5/20 00:37.
 */
public interface Message {
}
