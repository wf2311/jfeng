package com.wf2311.webot.exception;

/**
 * @author wf2311
 * @time 2017/5/20 00:51.
 */
public class WechatException extends RuntimeException {


    public WechatException() {
        super();
    }

    public WechatException(String message) {
        super(message);
    }

    public WechatException(Throwable cause) {
        super(cause);
    }

}
