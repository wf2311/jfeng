package com.wf2311.webot.service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.io.Files;
import com.wf2311.jfeng.regex.Matchers;
import com.wf2311.jfeng.time.DateHelper;
import com.wf2311.webot.Constant;
import com.wf2311.webot.exception.WechatException;
import com.wf2311.webot.model.WechatContact;
import com.wf2311.webot.model.WechatMeta;
import com.wf2311.webot.robot.Robot;
import com.wf2311.webot.robot.TulingRobot;
import jodd.http.HttpRequest;
import jodd.http.HttpResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;

/**
 * @author wf2311
 * @time 2017/5/20 00:49.
 */
@Slf4j
public class DefaultWechatService implements WechatService {
    private Robot robot = new TulingRobot();


    /**
     * 获取UUID
     *
     * @return
     */
    @Override
    public String getUUID() throws WechatException {
        HttpResponse response = HttpRequest.get(Constant.JS_LOGIN_URL)
                .query("appid", "wx782c26e4c19acffb")
                .query("fun", "new")
                .query("lang", "zh_CN")
                .query("_", DateHelper.currentUnixTimestamp())
                .charset("utf8").send();


        String text = response.body();
        response.close();

        if (StringUtils.isNotBlank(text)) {
            String code = Matchers.match("window.QRLogin.code = (\\d+);", text);
            if (null != code) {
                if ("200".equals(code)) {
                    return Matchers.match("window.QRLogin.uuid = \"(.*)\";", text);
                } else {
                    throw new WechatException("错误的状态码: " + code);
                }
            }
        }
        throw new WechatException("获取UUID失败");
    }

    /**
     * 获取登录二维码
     *
     * @param uuid
     * @return
     * @throws WechatException
     */
    public void copyQrCode(String uuid,File file) throws WechatException {
        byte[] bytes = HttpRequest.post(Constant.QRCODE_URL + uuid)
                .query("_", DateHelper.currentUnixTimestamp())
                .send().bodyBytes();
        try {
            Files.write(bytes,file);
        } catch (IOException e) {
            throw new WechatException("获取登录二维码失败:"+e.getMessage());
        }
    }

    /**
     * 微信初始化
     *
     * @param wechatMeta
     * @throws WechatException
     */
    @Override
    public void wxInit(WechatMeta wechatMeta) throws WechatException {

    }

    /**
     * 开启状态通知
     *
     * @param wechatMeta
     * @return
     */
    @Override
    public void openStatusNotify(WechatMeta wechatMeta) throws WechatException {

    }

    /**
     * 获取联系人
     *
     * @param wechatMeta
     * @return
     */
    @Override
    public WechatContact getContact(WechatMeta wechatMeta) throws WechatException {
        return null;
    }

    /**
     * 选择同步线路
     *
     * @param wechatMeta
     * @return
     * @throws WechatException
     */
    @Override
    public void choiceSyncLine(WechatMeta wechatMeta) throws WechatException {

    }

    /**
     * 消息检查
     *
     * @param wechatMeta
     * @return
     */
    @Override
    public int[] syncCheck(WechatMeta wechatMeta) throws WechatException {
        return new int[0];
    }

    /**
     * 处理聊天信息
     *
     * @param wechatMeta
     * @param data
     */
    @Override
    public void handleMsg(WechatMeta wechatMeta, JSONObject data) throws WechatException {

    }

    /**
     * 获取最新消息
     *
     * @param meta
     * @return
     */
    @Override
    public JSONObject webwxsync(WechatMeta meta) throws WechatException {
        return null;
    }
}
