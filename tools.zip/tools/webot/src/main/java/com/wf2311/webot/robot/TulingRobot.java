package com.wf2311.webot.robot;


import com.wf2311.webot.message.Message;

/**
 * @author wf2311
 * @time 2017/5/20 16:22.
 */
public class TulingRobot implements Robot {
    @Override
    public Message talk(Message message) {
        return null;
    }
}
