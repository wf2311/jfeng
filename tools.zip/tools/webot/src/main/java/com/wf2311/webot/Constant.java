package com.wf2311.webot;


import java.util.Arrays;
import java.util.List;

public interface Constant {

    String HTTP_OK = "200";
    String BASE_URL = "http://webpush2.weixin.qq.com/cgi-bin/mmwebwx-bin";
    String JS_LOGIN_URL = "http://login.weixin.qq.com/jslogin";
    String QRCODE_URL = "http://login.weixin.qq.com/qrcode/";

    String ITPK_API = "http://i.itpk.cn/api.php";
    String TULING_API = "http://www.tuling123.com/openapi/api";

    // 特殊用户 须过滤
    List<String> FILTER_USERS = Arrays.asList("newsapp", "fmessage", "filehelper", "weibo", "qqmail",
            "fmessage", "tmessage", "qmessage", "qqsync", "floatbottle", "lbsapp", "shakeapp", "medianote", "qqfriend",
            "readerapp", "blogapp", "facebookapp", "masssendapp", "meishiapp", "feedsapp", "voip", "blogappweixin",
            "weixin", "brandsessionholder", "weixinreminder", "wxid_novlwrv3lqwv11", "gh_22b87fa7cb3c", "officialaccounts",
            "notification_messages", "wxid_novlwrv3lqwv11", "gh_22b87fa7cb3c", "wxitil", "userexperience_alarm",
            "notification_messages");

    String[] SYNC_HOST = {
            "webpush.weixin.qq.com",
            "webpush2.weixin.qq.com",
            "webpush.wechat.com",
            "webpush1.wechat.com",
            "webpush2.wechat.com",
            "webpush1.wechatapp.com"
    };

//    WechatContact CONTACT;

    // 全局配置文件
//	public static Config config;
}
