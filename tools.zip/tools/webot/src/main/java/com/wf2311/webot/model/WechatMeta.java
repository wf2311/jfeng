package com.wf2311.webot.model;

import com.alibaba.fastjson.JSONObject;
import com.wf2311.webot.Constant;
import lombok.Data;

/**
 * @author wf2311
 * @time 2017/5/20 00:56.
 */
@Data
public class WechatMeta {
    private String base_uri;
    private String redirect_uri;
    private String webpush_url = Constant.BASE_URL;

    private String uuid;
    private String skey;
    private String synckey;
    private String wxsid;
    private String wxuin;
    private String pass_ticket;
    private String deviceId = "e" + System.currentTimeMillis()/1000;

    private String cookie;

    private JSONObject baseRequest;
    private JSONObject SyncKey;
    private JSONObject User;
}
