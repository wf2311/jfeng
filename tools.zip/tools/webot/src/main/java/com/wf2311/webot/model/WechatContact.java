package com.wf2311.webot.model;


import com.alibaba.fastjson.JSONArray;
import lombok.Data;

@Data
public class WechatContact {

	// 微信联系人列表，可聊天的联系人列表
	private JSONArray memberList;
	private JSONArray contactList;
	private JSONArray groupList;

}
