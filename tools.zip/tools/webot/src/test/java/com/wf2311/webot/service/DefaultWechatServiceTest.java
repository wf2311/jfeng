package com.wf2311.webot.service;

import org.junit.Test;

import java.io.File;

/**
 * @author wf2311
 * @time 2017/5/20 17:16.
 */
public class DefaultWechatServiceTest {
    WechatService service = new DefaultWechatService();
    @Test
    public void getUUID() throws Exception {
        String uuid = service.getUUID();
        System.out.println(uuid);
    }

    @Test
    public void copyQrCode() throws Exception {
        File file = new File("/Users/wf2311/Share/wechat.jpg");
         service.copyQrCode(service.getUUID(),file);
    }

}